//
//  ChatViewController.swift
//  MessageCursoViewCode
//
//  Created by Caio on 23/06/21.
//

import UIKit
import Firebase

class ChatViewController: UIViewController {
    
    
    var screen:ChatViewScreen?
    
    override func loadView() {
        self.screen = ChatViewScreen()
        self.view = screen
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @objc func tappedBackButton(){
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    

}
